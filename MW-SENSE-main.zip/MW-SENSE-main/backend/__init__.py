"""MW-SENSE API package."""
